//A ticketing App for Homabay County
package com.homabaycounty.homabaycounty.controller;

import com.homabaycounty.homabaycounty.model.User;
import com.homabaycounty.homabaycounty.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController

public class RegistrationController {
    //Using the autowired spring injection
    @Autowired
    private RegistrationService service;

    @PostMapping("/registerUser")

    //Method for handling the user details upon registration
    public User registerUser(@RequestBody User user) throws Exception{
        String tempEmailId = user.getEmailId();
        if (tempEmailId != null && !"".equals(tempEmailId)){
            User userObject= service.fetchUserByEmailId(tempEmailId);
            if(userObject != null) {
                throw new Exception("User with "+tempEmailId+" already exist");

            }


        }

        User userObject = null;
        userObject = service.saveUser(user);

        return userObject;

    }

    @PostMapping("/login")
    @CrossOrigin(origins = "http://localhost/4200")


    public User loginUser(@RequestBody User user) throws Exception{
        String tempEmailId = user.getEmailId();
        String tempPass = user.getPassword();

        User userObject = null;
        if (tempEmailId != null && tempPass != null ){
            userObject = service.fetchUserByEmailIdAndPassword(tempEmailId, tempPass);

        }
        if (userObject == null) {
            throw new Exception("Bad credentials");
        }
        return userObject;


    }




}
