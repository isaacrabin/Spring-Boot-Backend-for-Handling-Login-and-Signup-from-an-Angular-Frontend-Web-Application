package com.homabaycounty.homabaycounty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomabayCountyApplication {
    public static void main(String[] args){
        SpringApplication.run(HomabayCountyApplication.class, args);

    }
}
