package com.homabaycounty.homabaycounty.service;

import com.homabaycounty.homabaycounty.model.User;
import com.homabaycounty.homabaycounty.repository.Registration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationService {

    @Autowired
    private Registration repo;
    public User saveUser(User user){
        return repo.save(user);

    }
    public User fetchUserByEmailId(String email) {
       return repo.findByEmailId(email);
    }

    public User fetchUserByEmailIdAndPassword(String email,String pass) {
        return repo.findByEmailIdAndPassword(email, pass);

    }


}
