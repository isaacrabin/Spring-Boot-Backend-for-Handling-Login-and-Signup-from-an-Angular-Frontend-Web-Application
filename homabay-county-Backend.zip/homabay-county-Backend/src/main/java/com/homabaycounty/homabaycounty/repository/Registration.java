package com.homabaycounty.homabaycounty.repository;


import com.homabaycounty.homabaycounty.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Registration extends JpaRepository<User,Integer> {
    public User findByEmailId(String email);

    public User findByEmailIdAndPassword(String email, String pass);
}
